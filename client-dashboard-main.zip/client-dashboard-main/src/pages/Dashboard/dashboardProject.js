import { Typography } from "@mui/material";
import DashboardTab from "./dashboardAdminHeader";


export const Dashboard = () => {

  return (
    <div>
      <DashboardTab />
      <Typography>Dashboard project</Typography>
    </div>
  );
};
